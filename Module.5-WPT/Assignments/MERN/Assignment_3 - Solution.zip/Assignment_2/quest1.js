function changeStyle() {
    const paragraph = document.getElementById('text');
  
    paragraph.style.fontFamily = 'Verdana, sans-serif';
    paragraph.style.fontSize = '18px';
    paragraph.style.color = '#191970'; 
}
