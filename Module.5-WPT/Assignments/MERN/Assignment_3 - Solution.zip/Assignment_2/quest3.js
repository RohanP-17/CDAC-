function removeItem() {
    const dropdown = document.getElementById("itemList");
    dropdown.remove(dropdown.selectedIndex);
    
}
